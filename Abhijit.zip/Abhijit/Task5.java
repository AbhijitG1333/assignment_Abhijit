private static final Logger logger = LoggerFactory.getLogger(DocumentValidator.class);

public ValidationResult validate(Document doc) {
    try {
        if (doc == null) {
            // FIX: Use specific exception for validation failure (not RuntimeException)
            throw new IllegalArgumentException("Document is null");
        }

        String content = doc.extractContent();

        if (content == null || content.isEmpty()) {
            // FIX: Handle null + use meaningful exception
            throw new IllegalArgumentException("Empty content");
        }

        return runValidationRules(content);

    } catch (IllegalArgumentException e) {
        // FIX: Expected validation failure → log at WARN, no stack trace spam
        logger.warn("Validation failed: {}", e.getMessage());
        return new ValidationResult(false); // FIX: do not return null

    } catch (Exception e) {
        // FIX: Unexpected error → log full stack trace
        logger.error("Unexpected validation error", e);
        return new ValidationResult(false); // FIX: avoid null
    }
}

public void validateBatch(List<Document> docs) {
    for (Document doc : docs) {
        try {
            ValidationResult r = validate(doc);

            // FIX: Null-safe check before accessing result
            if (r != null && r.isValid()) {
                saveResult(r);
            }

        } catch (Exception e) {
            // FIX: Do not swallow exceptions silently
            logger.error("Error processing document in batch", e);
        }
    }
}