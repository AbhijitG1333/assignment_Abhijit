public class BankStatementBatchProcessor {

    private AtomicInteger processedCount = new AtomicInteger(0);

    public void process(List<StatementRecord> records) throws InterruptedException {

        // FIX: Reset counter at start of each run (was accumulating across runs)
        processedCount.set(0);

        ExecutorService executor = Executors.newFixedThreadPool(10);

        for (StatementRecord record : records) {
            executor.submit(() -> {
                processRecord(record);
                processedCount.incrementAndGet();
            });
        }

        executor.shutdown();

        // FIX: Ensure all tasks complete before reading count
        if (!executor.awaitTermination(5, TimeUnit.MINUTES)) {
            throw new RuntimeException("Timeout waiting for tasks");
        }
    }

    public int getProcessedCount() {
        return processedCount.get();
    }
}