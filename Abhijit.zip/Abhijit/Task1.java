public List<LoanAccount> getOverdueLoans(List<LoanAccount> accounts) {
    List<LoanAccount> result = new ArrayList<>();

    if (accounts == null) {
        return result;
    }

    Date today = new Date();

    for (LoanAccount account : accounts) {

        // FIX: Null check must come before any method access
        if (account == null) {
            continue;
        }

        // FIX: Prevent NPE when dueDate is null
        Date dueDate = account.getDueDate();
        if (dueDate == null) {
            continue;
        }

        // FIX: Handle zero/negative balance safely (avoid incorrect results)
        if (account.getOutstandingBalance() <= 0) {
            continue;
        }

        if (dueDate.before(today)) {
            result.add(account);
        }
    }
    return result;
}