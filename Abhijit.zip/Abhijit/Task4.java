public class ReportDAO {

    private DataSource dataSource;

    public List<ReportEntry> fetchMonthlyReport(String accountId,
                                                int month, int year)
                                                throws SQLException {
        List<ReportEntry> entries = new ArrayList<>();

        // FIX: Ensure all resources are properly closed using try-with-resources
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                 "SELECT * FROM report_entries " +
                 "WHERE account_id = ? AND MONTH(entry_date) = ? " +
                 "AND YEAR(entry_date) = ?"
             );
             ResultSet rs = ps.executeQuery() // FIX: include ResultSet in same try
        ) {

            ps.setString(1, accountId);
            ps.setInt(2, month);
            ps.setInt(3, year);

            while (rs.next()) {
                entries.add(mapRow(rs));
            }
        }

        return entries;
    }
}